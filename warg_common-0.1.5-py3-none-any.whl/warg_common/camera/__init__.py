"""
Camera module exports.
"""

from .base_camera import BaseCameraDevice
from .camera_factory import CameraOption, create_camera

# Lazy imports to avoid requiring all camera dependencies
# Users can import specific implementations if needed
__all__ = [
    "BaseCameraDevice",
    "CameraOption",
    "create_camera",
]

# Optional imports - only available if dependencies are installed
def __getattr__(name):
    """Lazy import camera implementations to avoid dependency errors."""
    if name == "CameraOpenCV":
        from .camera_opencv import CameraOpenCV
        return CameraOpenCV
    elif name == "ConfigOpenCV":
        from .camera_opencv import ConfigOpenCV
        return ConfigOpenCV
    elif name == "CameraPiCamera2":
        from .camera_picamera2 import CameraPiCamera2
        return CameraPiCamera2
    elif name == "ConfigPiCamera2":
        from .camera_picamera2 import ConfigPiCamera2
        return ConfigPiCamera2
    elif name == "CameraArducamIR":
        from .camera_arducamir import CameraArducamIR
        return CameraArducamIR
    elif name == "ArducamOutput":
        from .camera_arducamir import ArducamOutput
        return ArducamOutput
    raise AttributeError(f"module {__name__!r} has no attribute {name!r}")
